import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'widgets/chart.dart';
import 'widgets/Transactions.dart';

//import 'resources/transaction.dart';

void main() => runApp(Expense());

class Expense extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.purple[600],
          title: Center(
            child: Text(
              "Expense Manager",
              style: GoogleFonts.aBeeZee(
                fontSize: 18,
                fontWeight: FontWeight.w300,
              ),
            ),
          ),
        ),
        body: Column(
          children: <Widget>[
            Chart(),
            TransactionsList(),
          ],
        ),
      ),
    );
  }
}
