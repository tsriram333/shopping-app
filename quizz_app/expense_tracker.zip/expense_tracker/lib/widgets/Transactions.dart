import 'package:flutter/material.dart';

import 'txcard.dart';

class TransactionsList extends StatefulWidget {
  @override
  _TransactionsListState createState() => _TransactionsListState();
}

class _TransactionsListState extends State<TransactionsList> {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Text('hello'),
    );
  }
}
