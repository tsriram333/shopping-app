import 'package:flutter/material.dart';

class TransactionCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: <Widget>[
          Container(),
          Column(
            children: <Widget>[],
          )
        ],
      ),
    );
  }
}
